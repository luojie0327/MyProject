package com.example.util;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class FactoryUtil {
	
	private static FactoryUtil factoryUtil;
	//private static Map<String, HashMap<String, String>> usermap = new Map<String, HashMap<String,String>>; 
	private static HashMap<String, String>  usermap = new HashMap<String, String>();
	private FactoryUtil(){};
	
	public  static FactoryUtil getInstance(){
		if(factoryUtil == null){
			synchronized (FactoryUtil.class) {
				if(factoryUtil == null){
					factoryUtil = new FactoryUtil();
				}
			}
			
		}	

		return factoryUtil;
	}
	
	
	public void SaveUserMessage(String username,String password){
		
		usermap.put(username, password);
	}
	
	public HashMap<String, String> getMap(){
		return usermap;
	}
	
	
	
	public Boolean isLoginSuccess(String usename,String password){
		
		Boolean flag  = false;
		HashMap<String, String> map = getMap();
		Set set = map.keySet();
		Iterator<String> iterator = set.iterator();
		while(iterator.hasNext()){
			String username = iterator.next();
			String psd = map.get(username);
			if(username.equals(username)&& password.equals(psd)){
				flag = true;
				break;
			}
				
		}
		
		return flag;
		
	}
	
	
	public void printMap(HashMap<String, String> map){
		
	Set<String> set = map.keySet()	;
	
	Iterator<String> iterator = set.iterator();
	while(iterator.hasNext()){
		
		String name = iterator.next();
		String psd = map.get(name);
		System.out.println(name+":" +psd);
	}
	
		
	}
	
	
	

}
