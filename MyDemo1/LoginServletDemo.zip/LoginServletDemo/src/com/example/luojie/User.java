package com.example.luojie;

public class User {
	
	private String userneme;
	private String password;
	public String getUserneme() {
		return userneme;
	}
	public void setUserneme(String userneme) {
		this.userneme = userneme;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
