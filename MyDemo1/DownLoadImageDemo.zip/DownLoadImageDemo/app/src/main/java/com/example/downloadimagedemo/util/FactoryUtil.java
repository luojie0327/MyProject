package com.example.downloadimagedemo.util;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.example.downloadimagedemo.MyApplication;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import okhttp3.ResponseBody;

public class FactoryUtil {

    private static FactoryUtil factoryUtil ;
    private Context mContext;
    private static String url ;

    public  String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    private FactoryUtil(Context context){
        mContext = context;
    };

    public static FactoryUtil getInstance(){
        if(factoryUtil == null){
            synchronized (FactoryUtil.class) {
                if(factoryUtil ==null){
                    factoryUtil = new FactoryUtil(MyApplication.getMyApplication());
                }
            }
        }
        return  factoryUtil;
    }

    public boolean writeResponseBodyToDisk(ResponseBody body) {
        try {
            // todo change the file location/name according to your needs
            // File futureStudioIconFile = new File(getExternalFilesDir(null)  + "/Future Studio Icon.png");
            File futureStudioIconFile = new File(mContext.getCacheDir()  + "/Future Studio Icon.png");

            InputStream inputStream = null;
            OutputStream outputStream = null;

            try {
                byte[] fileReader = new byte[4096];

                long fileSize = body.contentLength();
                long fileSizeDownloaded = 0;

                inputStream = body.byteStream();
                outputStream = new FileOutputStream(futureStudioIconFile);

                while (true) {
                    int read = inputStream.read(fileReader);

                    if (read == -1) {
                        break;
                    }

                    outputStream.write(fileReader, 0, read);

                    fileSizeDownloaded += read;

                    //  Log.d("luojie", "file download: " + fileSizeDownloaded + " of " + fileSize);
                }

                outputStream.flush();

                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }

                if (outputStream != null) {
                    outputStream.close();
                }
            }
        } catch (IOException e) {
            return false;
        }
    }


}
