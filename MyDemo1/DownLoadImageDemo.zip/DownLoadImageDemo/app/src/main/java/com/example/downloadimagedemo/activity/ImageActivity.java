package com.example.downloadimagedemo.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.downloadimagedemo.R;
import com.example.downloadimagedemo.adaptor.MyRecycleViewAdaptor;
import com.example.downloadimagedemo.util.FactoryUtil;
import com.example.downloadimagedemo.view.MyRecycleView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ImageActivity extends AppCompatActivity {


    private MyRecycleView mRecyclerView;
    private MyRecycleViewAdaptor mAdapter;
    private ArrayList<String> mDatas;
    private ArrayList<Integer> localData;
    private ImageView mImg;
    private String baseurl = "http://" + FactoryUtil.getInstance().getUrl() + ":8080/LoginServletDemo/image/";
    private ArrayList<Integer> listData = new ArrayList<>();

    private Button button;
    private Button localImage;

    private Boolean upload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_layout);
        // requestWindowFeature(Window.FEATURE_NO_TITLE);

        upload = getIntent().getStringExtra("upload").equals("upload");
        initData();


        mImg = (ImageView) findViewById(R.id.id_content);
        mRecyclerView = (MyRecycleView) findViewById(R.id.id_recyclerview_horizontal);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mAdapter = new MyRecycleViewAdaptor(this, mDatas, localData,upload);
        mRecyclerView.setAdapter(mAdapter);


        mRecyclerView.setOnItemScrollChangeListener(new MyRecycleView.OnItemScrollChangeListener() {
            @Override
            public void onChange(View view, int position) {
                // Glide.with(ImageActivity.this).load(mDatas.get(position)).into(mImg);
                if (upload) {
                    Picasso.with(ImageActivity.this).load(localData.get(position)).into(mImg);
                } else {
                    Picasso.with(ImageActivity.this).load(mDatas.get(position)).into(mImg);
                }

            }
        });

        mAdapter.setOnItemClickLitener(new MyRecycleViewAdaptor.OnItemClickLitener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(getApplicationContext(), position + "", Toast.LENGTH_SHORT)
                        .show();
                if (upload) {
                    Picasso.with(ImageActivity.this).load(localData.get(position)).into(mImg);
                } else {
                    Picasso.with(ImageActivity.this).load(mDatas.get(position)).into(mImg);
                }

            }

        });

        button = findViewById(R.id.upload);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ImageActivity.this, WeixinActivity.class);
                startActivity(intent);

            }
        });

       /* localImage = findViewById(R.id.localImage);
        localImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listData = localData;
            }
        });*/


    }

    public void initData() {
        mDatas = new ArrayList<String>();
        localData = new ArrayList<Integer>();
        if (upload) {

            for (int i = 0; i < 2; i++) {

                localData.add(R.drawable.aa);
                localData.add(R.drawable.bb);
                localData.add(R.drawable.cc);
                localData.add(R.drawable.dd);
                localData.add(R.drawable.ee);
                localData.add(R.drawable.ff);
                localData.add(R.drawable.gg);
                localData.add(R.drawable.hh);
                localData.add(R.drawable.ii);
                localData.add(R.drawable.d);


            }
        } else {

            for (int i = 0; i < 20; i++) {
                mDatas.add(baseurl + i + ".jpeg");

            }
        }


    }
}