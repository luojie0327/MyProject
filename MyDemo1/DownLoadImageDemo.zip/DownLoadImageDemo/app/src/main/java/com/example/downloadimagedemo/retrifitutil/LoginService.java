package com.example.downloadimagedemo.retrifitutil;

import com.example.downloadimagedemo.model.AcountBean;

import io.reactivex.Observable;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface LoginService {
    @FormUrlEncoded
    @POST("/LoginServletDemo/LoginServlet")
    Call<ResponseBody> login(@Field("username") String username, @Field("password") String password);


    @FormUrlEncoded
    @POST("/LoginServletDemo/LoginServlet")
    Observable<AcountBean> login1(@Field("username") String username, @Field("password") String password);

}
