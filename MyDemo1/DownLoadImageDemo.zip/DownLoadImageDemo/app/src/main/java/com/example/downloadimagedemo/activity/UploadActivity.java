package com.example.downloadimagedemo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.downloadimagedemo.R;
import com.example.downloadimagedemo.util.RetrofitUtil;

public class UploadActivity extends AppCompatActivity {

    private Button upload_bt;
    private RetrofitUtil retrofitUtil =RetrofitUtil.getRetrofitUtil();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload_layout);
        upload_bt = findViewById(R.id.upload);
        upload_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // retrofitUtil.uploadImage();
            }
        });
    }
}