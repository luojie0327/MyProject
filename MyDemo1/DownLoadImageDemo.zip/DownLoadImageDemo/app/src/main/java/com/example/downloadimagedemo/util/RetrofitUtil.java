package com.example.downloadimagedemo.util;


import android.util.Log;

import com.example.downloadimagedemo.model.AcountBean;
import com.example.downloadimagedemo.retrifitutil.DownLoadService;
import com.example.downloadimagedemo.retrifitutil.LoginService;
import com.example.downloadimagedemo.retrifitutil.PostJsonUser;
import com.example.downloadimagedemo.retrifitutil.RegisterService;

import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitUtil {

    private Retrofit retrofit;
    private Boolean loginflag;
    private Boolean registerflag;
    private static RetrofitUtil retrofitUtil;
    //private String url = "http://"+192.168.29.2:8080+"/";
    private String url ;


    private RetrofitUtil(String url){
        this.url =  url;
    }

    public static RetrofitUtil getRetrofitUtil() {
        if(retrofitUtil == null){
            synchronized (RetrofitUtil.class){
                if(retrofitUtil == null){
                    retrofitUtil = new RetrofitUtil("http://"+FactoryUtil.getInstance().getUrl()+"8080/");
                }
            }
        }

        return retrofitUtil;
    }


    public Retrofit getRetrofit(String url) {


        retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit;

    }

    public void DownLoadImage() {


        DownLoadService downLoadService = getRetrofit(url).create(DownLoadService.class);
        Call<ResponseBody> call = downLoadService.DownLoadImage("1.png");
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                FactoryUtil.getInstance().writeResponseBodyToDisk(response.body());
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }


    public void uploadJson() throws IOException {

        PostJsonUser postJsonUser = getRetrofit(url).create(PostJsonUser.class);

        AcountBean acountBean = new AcountBean();
        acountBean.setPassword("123456");
        acountBean.setUsername("luojie");
        Gson gson = new Gson();
        String s = gson.toJson(acountBean);

        ResponseBody responseBody = ResponseBody.create(MediaType.parse("application/json; charset=utf-8"), s);

        Log.d("luojie", responseBody.string());
        Call<ResponseBody> call = postJsonUser.uploadJson(responseBody);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    Log.d("luojie", response.body().string());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }


    public Boolean userLogin(String username, String password) {

        String url ="http://"+FactoryUtil.getInstance().getUrl()+":8080/";
        Log.d("luojie",url);
        LoginService loginService = getRetrofit(url).create(LoginService.class);
        Call<ResponseBody> call = loginService.login(username, password);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {

                        loginflag = response.body().string().equals("true");


                    } catch (Exception e) {
                        loginflag = false;
                        e.printStackTrace();
                    }

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                loginflag = false;
            }
        });

        Log.d("luojie", loginflag + "");

        return loginflag;
    }

    public Boolean userRegister(String username, String password) {
        String url ="http://"+FactoryUtil.getInstance().getUrl()+":8080/";
        RegisterService registerService = getRetrofit(url).create(RegisterService.class);
        Call<ResponseBody> call = registerService.register(username, password);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    registerflag = response.body().string().equals("true");
                } catch (IOException e) {
                    e.printStackTrace();
                    registerflag = false;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                registerflag = false;
            }
        });


        return registerflag;
    }

}
