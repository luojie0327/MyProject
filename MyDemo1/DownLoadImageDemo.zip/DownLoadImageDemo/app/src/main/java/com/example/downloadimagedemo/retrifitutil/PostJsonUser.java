package com.example.downloadimagedemo.retrifitutil;

import com.example.downloadimagedemo.model.AcountBean;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface PostJsonUser {

    @Headers({"Content-Type: application/json","Accept: application/json"})//需要添加头
    @POST("json")
    Call<ResponseBody> uploadJson(@Body ResponseBody route);//传入的参数为RequestBody
}
