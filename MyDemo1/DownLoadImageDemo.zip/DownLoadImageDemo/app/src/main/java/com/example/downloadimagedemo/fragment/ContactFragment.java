package com.example.downloadimagedemo.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.downloadimagedemo.R;
import com.example.downloadimagedemo.adaptor.WeixinListViewAdaptor;
import com.example.downloadimagedemo.view.PullRefreshView;

import java.util.ArrayList;

public class ContactFragment extends Fragment {

    private PullRefreshView pullRefreshView ;


    private ArrayList<String> namelist;
    private ArrayList<Integer> imagelist;
    private WeixinListViewAdaptor adaptor;
    private Handler myHandle = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if(msg.what == 0x123){
                pullRefreshView.completeRefresh();
            }
        }
    };
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.contact_fragment,container,false);

return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        initData();
        pullRefreshView = view.findViewById(R.id.pull_listview);
        adaptor = new WeixinListViewAdaptor(getActivity(),namelist,imagelist,pullRefreshView);
        pullRefreshView.setAdapter(adaptor);
        pullRefreshView.setOnRefreshListener(new PullRefreshView.OnRefreshListener() {
            @Override
            public void onPullRefresh() {
                new Thread(){
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(5000);
                            myHandle.sendEmptyMessage(0x123);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }

            @Override
            public void onLoadingMore() {

            }
        });
    }

    public void initData(){
        namelist = new ArrayList<>();
        for (int i=0 ;i < 120 ;i++){
            namelist.add("路  飞" + i);
        }

        imagelist = new ArrayList<>();
        for(int i = 0 ;i < 30 ;i++){
            imagelist.add(R.drawable.a);
            imagelist.add(R.drawable.b);
            imagelist.add(R.drawable.c);
            imagelist.add(R.drawable.d);
        }

    }
}
