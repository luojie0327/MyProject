package com.example.downloadimagedemo.adaptor;

import android.content.Context;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.downloadimagedemo.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class WeixinListViewAdaptor extends BaseAdapter {
    private ArrayList<String> namelist;
    private ArrayList<Integer> imagelist;
    private Context mContext;
    private ListView listView;
    private int state;

    public WeixinListViewAdaptor(Context context,ArrayList<String> namelist,ArrayList<Integer> imagelist,ListView listView){
        this.mContext = context;
        this.namelist = namelist;
        this.imagelist = imagelist;
        this.listView = listView;
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                switch (scrollState){
                    case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:
                        updateUi();
                        state = 0;
                        break;
                    case     AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                        state = 1;
                        break;
                    case AbsListView.OnScrollListener.SCROLL_STATE_FLING://快速滑动    2
                        state=2;
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
    }
    @Override
    public int getCount() {
        return namelist.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView( int position,  View convertView, ViewGroup parent) {
         ViewHolder viewHolder;

        if(convertView == null){
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.weixin_item,parent,false);
            viewHolder.frameLayout = convertView.findViewById(R.id.frame_layout);
            viewHolder.imageView = convertView.findViewById(R.id.image_item);
            viewHolder.textView = convertView.findViewById(R.id.name_item);
            viewHolder.reflash = convertView.findViewById(R.id.reflsh);
            viewHolder.delete = convertView.findViewById(R.id.delete);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();

        }

        View finalConvertView = convertView;
        viewHolder.reflash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateView(finalConvertView,position);
            }
        });

        viewHolder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                namelist.remove(position);
                imagelist.remove(position);
                notifyDataSetChanged();
            }
        });


        viewHolder.textView.setText(namelist.get(position));


        if(state != 2){

            Glide.with(mContext).load(imagelist.get(position)).into((viewHolder.imageView));
            //Picasso.with(mContext).load(imagelist.get(position)).into(viewHolder.imageView);
        }else {
           viewHolder.imageView.setImageResource(R.drawable.ic_launcher_background);
        }


        return convertView;
    }


    /**
     69      * 局部刷新
     70      * @param view
     71      * @param itemIndex
     72      */
    public void updateView(View view, int itemIndex) {
            if(view == null) {
           return;
            }
      //从view中取得holder
        ViewHolder viewHolder = (ViewHolder) view.getTag();
        viewHolder.frameLayout = view.findViewById(R.id.frame_layout);
        viewHolder.imageView = view.findViewById(R.id.image_item);
        viewHolder.textView = view.findViewById(R.id.name_item);
        viewHolder.reflash = view.findViewById(R.id.reflsh);

        Glide.with(mContext).load(imagelist.get(0)).into(viewHolder.imageView);
        viewHolder.textView.setText(namelist.get(0));

  }


    public void updateUi(){
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    class ViewHolder{
        FrameLayout frameLayout;
        ImageView imageView ;
        TextView textView ;
        Button reflash;
        Button delete;
        public ViewHolder (){};
    }
}
