package com.example.downloadimagedemo.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.downloadimagedemo.R;
import com.example.downloadimagedemo.adaptor.WeixinListViewAdaptor;

import java.util.ArrayList;

public class WeixinFragment extends Fragment {

    private ArrayList<String> namelist;
    private ArrayList<Integer> imagelist;
    private ListView listView;
    private WeixinListViewAdaptor adaptor;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.weixin_fragment, container, false);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        initData();
        listView = view.findViewById(R.id.weixin_listview);
        adaptor = new WeixinListViewAdaptor(getActivity(), namelist, imagelist, listView);
        listView.setAdapter(adaptor);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView textView = view.findViewById(R.id.name_item);
                Button reflash = view.findViewById(R.id.reflsh);
                reflash.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                             updateView(position);
                        Log.d("luojie","+++++++++");
                    }
                });
                Toast.makeText(getActivity(), textView.getText(), Toast.LENGTH_SHORT).show();
            }
        });


    }


    private void updateView(int itemIndex) {
        //得到第一个可显示控件的位置，
        int visiblePosition = listView.getFirstVisiblePosition();
        //只有当要更新的view在可见的位置时才更新，不可见时，跳过不更新
        if (itemIndex - visiblePosition >= 0) {
            //得到要更新的item的view
            View view = listView.getChildAt(itemIndex - visiblePosition);
            //调用adapter更新界面
            adaptor.updateView(view, itemIndex);
        }
    }

    public void initData() {
        namelist = new ArrayList<>();
        for (int i = 0; i < 120; i++) {
            namelist.add("路  飞" + i);
        }

        imagelist = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            imagelist.add(R.drawable.a);
            imagelist.add(R.drawable.b);
            imagelist.add(R.drawable.c);
            imagelist.add(R.drawable.d);
        }

    }
}
