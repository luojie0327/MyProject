package com.example.downloadimagedemo.adaptor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.downloadimagedemo.R;

import java.util.ArrayList;


public class MyRecycleViewAdaptor extends RecyclerView.Adapter<MyRecycleViewAdaptor.ViewHolder> {

    private Context mContext;
    private ArrayList<String> imageList;
    private ArrayList<Integer> locallist;
    private Boolean upload;

    public MyRecycleViewAdaptor( Context context,ArrayList<String> imageList,ArrayList<Integer> locallist,Boolean upload) {
        this.mContext = context;
        this.imageList = imageList;
        this.locallist = locallist;
        this.upload = upload;

    }




    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_view, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        viewHolder.imageView = view.findViewById(R.id.item_view);

        return viewHolder;
    }


    /**
     * ItemClick的回调接口
     */
    public interface OnItemClickLitener {
        void onItemClick(View view, int position);
    }

    private OnItemClickLitener mOnItemClickLitener;

    public void setOnItemClickLitener(OnItemClickLitener mOnItemClickLitener) {
        this.mOnItemClickLitener = mOnItemClickLitener;
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if(upload){
            Glide.with(mContext).load(locallist.get(position)).into(holder.imageView);
        }else {
            Glide.with(mContext).load(imageList.get(position)).into(holder.imageView);
        }


         /*Picasso.with(mContext)
                .load(imageList.get(position))
                 .error(locallist.get(position))
                .into(holder.imageView);*/

        //如果设置了回调，则设置点击事件
        if (mOnItemClickLitener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mOnItemClickLitener.onItemClick(holder.itemView, position);
                }
            });

        }

    }


    @Override
    public int getItemCount() {
   return  imageList.size() + locallist.size();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
        }
    }
}
