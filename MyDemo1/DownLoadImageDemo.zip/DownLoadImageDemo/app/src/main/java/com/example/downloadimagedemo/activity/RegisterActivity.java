package com.example.downloadimagedemo.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.downloadimagedemo.R;
import com.example.downloadimagedemo.util.FactoryUtil;
import com.example.downloadimagedemo.util.RetrofitUtil;

import java.util.Timer;
import java.util.TimerTask;

import io.reactivex.Scheduler;

public class RegisterActivity extends AppCompatActivity {

    private EditText register_username;
    private EditText register_password;
    private Boolean registersucess = true;
    private Button register_bt;
    private TextView textView;
    private int time = 0;


    private RetrofitUtil retrofitUtil = RetrofitUtil.getRetrofitUtil();
    private Timer timer = new Timer();
    private TimerTask task = new TimerTask() {


        @Override
        public void run() {
            myHandle.sendEmptyMessage(0x123);
        }
    };

    private Handler myHandle = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 0x123) {
                time ++ ;
                textView.setText("倒计时 :" + time);
                if(time == 5){
                    Toast.makeText(RegisterActivity.this,"注册成功!!",Toast.LENGTH_LONG).show();
                    finish();
                }

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        register_username = findViewById(R.id.register_username);
        register_password = findViewById(R.id.register_password);
        register_bt = findViewById(R.id.register_bt);
        textView = findViewById(R.id.textview);



        register_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = register_username.getText().toString();
                String psd = register_password.getText().toString();
                if (username.trim().equals("") || psd.trim().equals("")) {
                    Toast.makeText(RegisterActivity.this, "用户名密码不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }

                registersucess = retrofitUtil.userRegister(username, psd);
                if (registersucess != null && registersucess) {
                    timer.schedule(task, 0, 1000);
                }
            }
        });


    }
}