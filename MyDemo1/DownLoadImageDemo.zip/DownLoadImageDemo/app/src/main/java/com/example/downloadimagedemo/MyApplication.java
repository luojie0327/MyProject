package com.example.downloadimagedemo;

import android.app.Application;

public class MyApplication  extends Application {

    private static MyApplication myapp;



    public  static  MyApplication getMyApplication(){
        return myapp;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        myapp = this;
    }
}
