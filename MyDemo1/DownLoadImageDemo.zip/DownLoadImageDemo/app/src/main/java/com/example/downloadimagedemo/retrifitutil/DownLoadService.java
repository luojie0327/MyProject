package com.example.downloadimagedemo.retrifitutil;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Url;

public interface DownLoadService {

    @GET("image/{path}")
    Call<ResponseBody> DownLoadImage(@Path("path") String path);
}
