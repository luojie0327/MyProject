package com.example.downloadimagedemo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.Toast;

import com.example.downloadimagedemo.R;
import com.example.downloadimagedemo.util.FactoryUtil;
import com.example.downloadimagedemo.util.RetrofitUtil;
import com.google.android.material.checkbox.MaterialCheckBox;

public class LoginActivity extends AppCompatActivity {

    private EditText ipnum;
    private EditText username;
    private EditText password;

    private Button summit;
    private Button loginButton;
    private Button registerButton;
    private Button unlogin;

    private MaterialCheckBox checkable;
    private SharedPreferences sharedPreferences ;

    private RetrofitUtil retrofitUtil = RetrofitUtil.getRetrofitUtil();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);

        sharedPreferences  = getSharedPreferences("user", Context.MODE_PRIVATE);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        ipnum = findViewById(R.id.ipnum);

        summit = findViewById(R.id.summit);
        loginButton = findViewById(R.id.login);
        registerButton = findViewById(R.id.register);
        unlogin = findViewById(R.id.unlogin);
        checkable = findViewById(R.id.checkbox_bt);

        init();

        summit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FactoryUtil.getInstance().setUrl(ipnum.getText().toString());
                Log.d("luojie",FactoryUtil.getInstance().getUrl());
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String ip = ipnum.getText().toString();
                String name = username.getText().toString();
                String psd = password.getText().toString();

                if(name.trim().equals("") || psd.trim().equals("") ){
                    Toast.makeText(LoginActivity.this,"请输入用户名或者密码！",Toast.LENGTH_LONG).show();
                    return;
                }
                else if(ip.trim().equals("")){
                    Toast.makeText(LoginActivity.this,"请输入部署tomcat的ip！",Toast.LENGTH_LONG).show();
                    return;
                }


                if(checkable.isChecked()){
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("username",name);
                    editor.putString("password",psd);
                    editor.putBoolean("check",checkable.isChecked());
                    editor.commit();
                }else {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("username","");
                    editor.putString("password","");
                    editor.putBoolean("check",checkable.isChecked());
                    editor.commit();
                }



                if( retrofitUtil.userLogin(name, psd) != null && retrofitUtil.userLogin(name, psd)){
                Intent intent = new Intent(LoginActivity.this,ImageActivity.class);
                    intent.putExtra("upload","load");
                startActivity(intent);
                finish();
                }else{
                    Toast.makeText(LoginActivity.this,"用户名或者密码错误",Toast.LENGTH_SHORT).show();
                    username.setText("");
                    password.setText("");
                }


            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);

            }
        });

        unlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,ImageActivity.class);
                intent.putExtra("upload","upload");
                startActivity(intent);
                finish();
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();

}
public void init(){
    Boolean check = sharedPreferences.getBoolean("check",false);
    if(!check){
        username.setText("");
        password.setText("");
        checkable.setChecked(check);
    }
    String name = sharedPreferences.getString("username",null);
    String psd = sharedPreferences.getString("password",null);
    username.setText(name);
    password.setText(psd);
    checkable.setChecked(check);


}

    }
